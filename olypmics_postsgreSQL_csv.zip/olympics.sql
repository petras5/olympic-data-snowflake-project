
-- national olympic comittee - nacija/regija za koju se sportasi natjecu
create table public.noc
(
    noc_id char(3) not null
        constraint noc_regions_pk
            primary key,
    region varchar
);

alter table public.noc
    owner to postgres;

-- medalje koje je moguce osvojiti
create table public.medal
(
    medal_id   smallint not null
        constraint medal_pk
            primary key,
    medal_name char(10)
);

alter table public.medal
    owner to postgres;

-- grad u kojem su odrzane igre i kojoj regiji pripada
create table public.city
(
    city_id   serial
        primary key,
    city_name varchar,
    noc_id    char(3)
        constraint city_noc_fk
            references public.noc
);

alter table public.city
    owner to postgres;

-- odrzane igre (grad, godine, naziv igara)
create table public.games
(
    games_id     serial
        primary key,
    games_year   smallint,
    games_season char(10),
    city_id      smallint
        constraint games_city_fk
            references public.city,
    games_name   varchar(40)
);

alter table public.games
    owner to postgres;

-- sportasi 
create table public.athlete
(
    athlete_id     integer not null
        primary key,
    athlete_name   varchar,
    athlete_gender char,
    athlete_height smallint,
    athlete_weight smallint,
    athlete_yob    smallint  -- yob = year of birth
);

alter table public.athlete
    owner to postgres;

-- naziv sporta u kojem se natjecu
create table public.sport
(
    sport_id   serial
        primary key,
    sport_name varchar
);

alter table public.sport
    owner to postgres;

-- discipline i kojem sportu pripadaju
create table public.event
(
    event_id   serial
        primary key,
    event_name varchar,
    sport_id   smallint
        constraint event_sport_fk
            references public.sport
);

alter table public.event
    owner to postgres;

-- sudjelovanje sportasa u pojedioj disciplini na nekim igrama, 
-- za koju naciju je nastupio/la i eventualno osvojene medalje
create table public.athlete_event
(
    athlete_id integer default nextval('olympics_id_seq'::regclass) not null
        constraint athlete_event_athlete_fk
            references public.athlete,
    noc_id     char(3)
        constraint athlete_event_noc_fk
            references public.noc,
    medal_id   smallint
        constraint athlete_event_medal_fk
            references public.medal,
    games_id   smallint
        constraint athlete_event_games_fk
            references public.games,
    event_id   smallint
        constraint athlete_event_event_fk
            references public.event
);

alter table public.athlete_event
    owner to postgres;

